import openpyxl 
import pandas as pd
import matplotlib.pyplot as plt

wb = openpyxl.Workbook()

ws = wb.active

ws.title = "student"

ws.append(["Name","Math","Science","English","Computer"])
ws.append(["Aayush",85,56,76,54])
ws.append(["Naman",45,86,34,76])
ws.append(["Shivam",65,77,55,65,])
ws.append(["Raghav",98,54,76,87])
ws.append(["Pooja",54,87,67,90])
ws.append(["Sakshi",67,78,56,87])
ws.append(["Somay",95,62,88,68])


wb.save("student.xlsx")

print("excel file created")


df = pd.read_excel("student.xlsx")
print("dtaa loaded")
print(df)

df["average"] = df[["Math","Science","English","Computer"]].mean(axis=1)
print(df[["Name",'average']])

df["result"] = df["average"].apply(lambda x:"pass" if x >= 60 else "fail")
print(df[["Name","average","result"]])
lowest = df.loc[df["average"].idxmin()]
print(f"lowest: {lowest['Name']} - {lowest['average']}")
print(f"Class Average: {df['average'].mean():.2f}")

plt.figure(figsize=(10,6))
plt.bar(df["Name"],df['average'],color = 'skyblue')
plt.title("student average marks")
plt.xlabel('Student')
plt.ylabel('Average  marks')
plt.axhline(y = 60,color='red', linestyle='--', label= "pass")
plt.legend()
plt.show()

df.to_excel("result.xlsx", index=False)
print("\nresult saved")