###INHERITNACE
# 
"""SINGLE INHERITNAC E"""
class student:
    def __init__(self,name):
        self.name = name

    def eat(self):
        print(f"{self.name} is eating")

class dog(animal): # type: ignore

    def bark(self):
        print(f"{self.name}")

d = dog("shiru")
d.obj()

