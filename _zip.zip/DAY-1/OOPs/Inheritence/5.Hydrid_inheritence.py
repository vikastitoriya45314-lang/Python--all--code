
class father:
    def property(self):
        print("father goes to office")

class son(father):
    def cricket(self):
        print('plays cricket')

class daughter(father,son): # pyright: ignore[reportGeneralTypeIssues]
    def sings(self):
        print("ajhf")

s = son()
s.property()
s.cricket()

d = daughter()
d.property()
d.sings()
