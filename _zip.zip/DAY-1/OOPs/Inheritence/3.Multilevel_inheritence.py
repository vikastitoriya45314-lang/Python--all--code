class car:
    def vehicle(self):
        print('its car')

class bmw(car):
    def speed(self):
        print('it focus on speed')

class audi(bmw):
    def design(self):
        print('designs the cars')


