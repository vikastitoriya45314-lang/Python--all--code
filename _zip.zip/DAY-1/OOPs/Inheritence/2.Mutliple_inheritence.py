class camera():
    def clickphotos(self):
        print("clicked photo")

class phone:
    def call(self):
        print("calling")

class smartphone(camera,phone):
    def browser(self):
        print("browse")

    def gallery(self):
        print("gallery")

s = smartphone()
s.clickphotos()
s.call()
s.browser()
s.gallery()

