from abc import ABC, abstractmethod

class Principal(ABC):
    #abstractmethod
    def wear_uniform(self):
        pass
    def do_HW(self):
        pass

class student(Principal):
    def wear_uniform(self):
        print('in uniform')

    def do_HW(self):
        print('HW done')

s = student()
s.wear_uniform()
s.do_HW()

###if one function is not done then it will get error like of do_hw in not created
