from abc import ABC, abstractmethod
class ATM(ABC):
    @abstractmethod
    def withdraw(self):
        pass
    @abstractmethod
    def check_balance(self):
        pass

class ABI(ATM):
    def withdraw(self):
        server = "sbi server"
        language = "apache"
        db = 'monogo'
        print('cash withdraw')

    def check_balance(self):
        server = 'SERVER ABI'
        language = "langu"
        db = 'monogo' 
        print('balacne: 1000000')

sbi = ABI()
sbi.withdraw()
sbi.check_balance()


