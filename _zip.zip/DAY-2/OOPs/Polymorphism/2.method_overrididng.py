class father:
    def marriage(self):
        print('marry to aysa')

class son(father):
    def marriage(self):
        print('print to mitali')

s=son()
s.marriage()