a = 12
b = 12

try:
    print(a/b)
except:
    print("not divisible by 0")

print("hello")
