class instagram:
    __password = "turtle123"
    __followers = 700

    def changepassword(self, old, new):
        if old == self.__password:
            self.__password = new
            print('password changed seucessfully')
        else:
            ('error! wrong password')
    
    def addfollowers(self):
        self.__followers += 1
        print(f'New follower! total{self.__followers}')

    def getfollower(self):
        print(f'followers ; {self.getfollower}')

acc = instagram()
acc.changepassword('turtle123','newpass344')
acc.addfollowers()
acc.getfollower()


### by using print we cant access the class directly so when we use print it will show erroe
