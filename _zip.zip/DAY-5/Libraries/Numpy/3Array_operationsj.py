import numpy as np

marks = np.array([60,70,52,65,26,65,45])

print(f'total, {np.sum(marks)}')
print(f'mean, {np.mean(marks)}')
print(f'max, {np.max(marks)}')
print(f'min, {np.min(marks)}')