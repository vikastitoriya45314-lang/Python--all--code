
import numpy as np 

n = np.array([1,2,3,4,5])

print(n*2)
print(type(n))


