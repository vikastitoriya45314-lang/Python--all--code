# import matplotlib.pyplot as plt

# players = ['ronaldo', 'neymar', 'messi', 'sunil']
# goals = [94, 56, 44, 100]

# plt.bar(players, goals)
# plt.title("FIFA Players")
# plt.xlabel("Players")
# plt.ylabel("Goals")

# plt.show()


import matplotlib.pyplot as plt

players = ['ronaldo', 'neymar', 'messi', 'sunil']
goals = [94, 56, 44, 100]

plt.plot(players, goals, marker='o')
plt.title("FIFA Players")
plt.xlabel("Players")
plt.ylabel("Goals")

plt.show()

plt.pie([40,35,40,50], labels=['messi','neymar','ronaldo','sunil'])
plt.show()