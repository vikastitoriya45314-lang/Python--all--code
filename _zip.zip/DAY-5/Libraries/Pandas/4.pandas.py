import pandas as pd

players = {
    "players": ['cr7', 'messi', 'neymar'],
    "goals": [5,7,8]
}

df = pd.DataFrame(players)

# print(df)
# print(df['players'])
print(df['goals'].sum())
print(df['goals'].mean())
print(df[df['goals'] > 6])