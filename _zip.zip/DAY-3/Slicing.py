even = [i for i] in range (1,11) if i % 2==0)
print(even)
# squres
squres = [i*i for i in range(1,6)]
print(squres) #[1,2,3,4,5]