f = open('file.txt','w')
f.write('hello')
f.close()
print('file created')

f = open('file.txt','r')
constant = f.read()
print('constant')
f.close()

f = open('file.txt','a')
f.write('apple fruit')
f.close()
print('data added')

