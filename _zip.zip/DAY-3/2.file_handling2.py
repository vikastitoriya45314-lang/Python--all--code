with open("file2.txt",'w')as f:
    f.write("tanishq - 30", /n)
    f.write('tariq - 30'/n)

