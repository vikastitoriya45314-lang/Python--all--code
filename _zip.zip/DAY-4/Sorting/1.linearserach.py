array = [22,66,3,22,97,99]

target = 97

for i in range(len(array)):
    if array[i]  == target:
        print("target value" , i)
    else:
        print("not found")