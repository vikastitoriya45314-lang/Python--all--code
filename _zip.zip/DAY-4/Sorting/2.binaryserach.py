### list must be sorted 

array = []