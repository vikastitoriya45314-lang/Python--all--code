list1 = [12,23,54,65]
list1[0] = 100

print(list1)