d = {
    "name":"tanishq",
    "age": 22,
    "city": "bhopal"

}

print(d)
print(d["name"])
print(d["age"])

d["location"] = "durgesh vihar"
print(d["location"])

del d["age"]
