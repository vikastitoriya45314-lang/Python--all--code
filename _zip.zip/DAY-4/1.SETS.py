number = {1,2,3,4,4,5,5,6,6,4,7,6}
print("number")

number.add(4)

#duplicacy allowed