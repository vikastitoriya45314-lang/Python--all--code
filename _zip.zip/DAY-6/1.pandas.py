import pandas as pd
df = pd.read_csv("demo.csv")
print(df.head())
print(df.info())
print(df.describe())