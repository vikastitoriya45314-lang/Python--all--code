import requests
from bs4 import BeautifulSoup
import json

url = "https://www.sheryians.com/"
response = requests.get(url)
print(response.status_code)
print(response.text)

soup = BeautifulSoup(response.text, "html.parser")




if soup.title:
    print("Title:", soup.title.text)

h1 = soup.find("h1")
if h1:
    print(h1.text)

p = soup.find("p")
if p:
    print(p.text)

# title = soup.title.text #########replaced by upper
# print(f'title: {title}')

# h1 = soup.find('h1')
# print({h1.text})

# p = soup.find("p")
# print({p.text})




links = soup.find_all("a")

for link in links:
    print(link.text)
    print(link.get("href"))

data =[]
for quote, author in zip(quotes,authors):
    data.append({
        "quote": quote.text,
        "author":author
    })
with open ('quote.json','w') as f:
    json.dump(data,f,indent=4)
print('data saved')